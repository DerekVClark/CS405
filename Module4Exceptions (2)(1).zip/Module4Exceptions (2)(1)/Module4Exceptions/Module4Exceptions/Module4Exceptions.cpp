// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

class CustomException : public std::exception { // Creates custom exception class derived from std::exception
private: // Private field
	std::string exceptionMessage; // Initializes private exception message 
public: // Public field
	CustomException() : exceptionMessage("Custom exception") {} // Initializes the exception mesage to string
	const char* what() const noexcept override // Overrides what methodn from std::exceptions and prevents it from throwing exceptions
	{
		return exceptionMessage.c_str(); // converts the string to a c-style string and returns it
	}

};

bool do_even_more_custom_application_logic()
{
	
    // TODO: Throw any standard exception *completed
	throw std::invalid_argument("Standard exception invalid argument"); // Throws an invalid argument exception with the message "Standard exception invalid argument"
	std::cout << "Running Even More Custom Application Logic." << std::endl;

    return true;
}
void do_custom_application_logic()
{
    // TODO: Wrap the call to do_even_more_custom_application_logic() *completed
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing

    std::cout << "Running Custom Application Logic." << std::endl;
	try {
		if (do_even_more_custom_application_logic())
		{
			std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
		}
	}
	catch (std::exception& e)
	{
		std::cout << "Exception caught: " << e.what() << std::endl;
	}

    // TODO: Throw a custom exception derived from std::exception *completed
    //  and catch it explictly in main
	
	throw CustomException(); // Throws a custom exception derived from std::exception
	std::cout << "Leaving Custom Application Logic." << std::endl;
    
    

}

float divide(float num, float den)
{
    // TODO: Throw an exception to deal with divide by zero errors using *completed
    //  a standard C++ defined exception
	if (den == 0) //If the denominator is equal to zero , throw an exception as dividing by zero is not allowed
	{
		throw std::runtime_error("Divide by zero exception"); // Throws a run time error detailing that the division by zero is not allowed (Causes undefined behavior)
	}
	return (num / den); // If the denominator is not zero, return the result of the division
}

void do_division() noexcept
{
    //  TODO: create an exception handler to capture ONLY the exception thrown *completed
    //  by divide.

    float numerator = 10.0f;
    float denominator = 0;
	try {
		auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
	}
	catch (std::runtime_error& e)
	{
		std::cout << "Exception caught: " << e.what() << std::endl;
	}
    
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    // TODO: Create exception handlers that catch (in this order): *completed
    //  your custom exception
    //  std::exception
    //  uncaught exception 
    //  that wraps the whole main function, and displays a message to the console.
	try { // Wrapns the whole main function in a try block
		do_division();
		do_custom_application_logic();
	} catch(CustomException& e) // Catches the custom exception first
	{
		std::cout << "Custom exception caught: " << e.what() << std::endl; 
	}
	catch (std::exception& e) // Catches the std::exception second
	{
		std::cout << "Exception caught: " << e.what() << std::endl;
	}
	catch (...) // Catches any uncaught exceptions third
	{
		std::cout << "Uncaught exception" << std::endl;
	}
	std::cout << "Exception Tests Complete!" << std::endl; // Diplays the message that the exception tests are complete
	return 0;
    
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
